import json

class Process:
    def __init__(self, pid, arrival, burst):
        self.pid = pid
        self.arrival = arrival
        self.burst = burst
        self.completion = 0
        self.waiting = 0
        self.turnaround = 0

def load_processes_from_json(path):
    with open(path, 'r') as f:
        data = json.load(f)
        return [Process(p["pid"], p["arrival"], p["burst"]) for p in data]

def fcfs(processes):
    processes.sort(key=lambda p: p.arrival)
    time = 0
    for p in processes:
        if time < p.arrival:
            time = p.arrival
        p.waiting = time - p.arrival
        time += p.burst
        p.completion = time
        p.turnaround = p.completion - p.arrival

    print("\nFCFS Scheduling:")
    for p in processes:
        print(f"P{p.pid} WT={p.waiting} TAT={p.turnaround}")
    print_detailed_timeline(processes, time)

def sjf_non_preemptive(processes):
    n = len(processes)
    complete = 0
    time = 0
    visited = [False] * n
    result = []

    while complete < n:
        idx = -1
        min_burst = float('inf')
        for i, p in enumerate(processes):
            if p.arrival <= time and not visited[i] and p.burst < min_burst:
                min_burst = p.burst
                idx = i

        if idx == -1:
            time += 1
            continue

        p = processes[idx]
        visited[idx] = True
        p.waiting = time - p.arrival
        time += p.burst
        p.completion = time
        p.turnaround = p.completion - p.arrival
        result.append(p)
        complete += 1

    print("\nSJF Non-Preemptive Scheduling:")
    for p in result:
        print(f"P{p.pid} WT={p.waiting} TAT={p.turnaround}")
    print_detailed_timeline(result, time)

def print_detailed_timeline(processes, total_time):
    print("\nTimeline detalhada:")
    for p in processes:
        line = []
        start = p.completion - p.burst
        for t in range(total_time):
            if t >= p.arrival and t < start:
                line.append('-')
            elif t >= start and t < p.completion:
                line.append('#')
            else:
                line.append('_')
        print(f"P{p.pid}: {''.join(line)}")

if __name__ == "__main__":
    procs = load_processes_from_json("processos.json")
    fcfs([Process(p.pid, p.arrival, p.burst) for p in procs])
    sjf_non_preemptive([Process(p.pid, p.arrival, p.burst) for p in procs])
